# Decision Center Workshop Kit

Design and operate a living leadership system across five domains, with explicit signals, decisions, interventions, and cadence.
