# ODM Baseline Workshop Kit

Establish observable current state, select the highest-value learning opportunity, and frame one bounded ODM adoption bet.
