# Learning Loop Workshop Kit

Complete instructor, participant, executive, canvas, review, and presentation materials.
