# ODM Leadership Workshop Kit

## Included materials

- START-HERE.pdf
- Leadership-Workshop-Instructor-Guide.pdf
- Leadership-Workshop-Participant-Workbook.pdf
- Leadership-Workshop-Executive-Brief.pdf
- Leadership-Attention-Profile.pdf
- Decision-Quality-Canvas.pdf
- Leadership-Review-Agenda.pdf
- Leadership-Workshop-Slides.pptx
- Leadership-Workshop-Slides.pdf

## Workshop outputs

- Outcome Alignment Map
- Current Reality and Risk Map
- Leadership Attention Profile
- Decision Quality Canvas
- Priority Decision Inventory
- 90-Day Leadership Commitments

## Important use note

These are proposed ODM workshop materials. Adapt them to organizational policy and context. Do not use them to rank individuals or teams.
